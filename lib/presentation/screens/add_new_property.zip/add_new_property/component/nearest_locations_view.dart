import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../data/model/create_property/nearest_location_dto.dart';
import '../../../../data/model/product/nearest_location_model.dart';
import '../../../../logic/bloc/create_property/bloc/property_create_bloc.dart';
import '../../../../logic/bloc/create_property/nearest_location/nearest_location_cubit.dart';
import '../../../../logic/cubit/create_property/create_info_cubit.dart';
import '../../../utils/constraints.dart';
import '../../../utils/utils.dart';
import '../../../widget/custom_test_style.dart';
import '../../../widget/form_header_title.dart';
import '../../../widget/item_add_delete_btn.dart';

class NearestLocationView extends StatefulWidget {
  const NearestLocationView({super.key});

  @override
  State<NearestLocationView> createState() => _NearestLocationViewState();
}

class _NearestLocationViewState extends State<NearestLocationView> {
  @override
  Widget build(BuildContext context) {
    final propertyBloc = context.read<PropertyCreateBloc>();
    final createInfoCubit = context.read<CreateInfoCubit>();
    final locationCubit = context.read<NearestLocationCubit>();
    //print('edit-info ${propertyBloc.editInfo!.existingNearest.length}');
    // print('controller-length ${locationCubit.distanceController.length}');
    return BlocBuilder<NearestLocationCubit, NearestLocationState>(
      builder: (context, state) {
        locationCubit.nearestLocationModel.insert(
            0, createInfoCubit.createPropertyInfo!.nearestLocations!.first);
        if (state is NearestLocationAdded || state is NearestLocationRemoved) {
          final nearestLocations =
              (state as NearestLocationAdded).nearestLocation;
          //print('nearestLocations-length ${nearestLocations.length}');
          //print('nearestLocations-length $nearestLocations');

          for (int i = 0; i < locationCubit.distanceController.length; i++) {
            //print('locationCubit.distanceController');
            final itemText = locationCubit.distanceController[i].text;
            if (itemText.isNotEmpty) {
              propertyBloc.add(PropertyNearestLocationEvent(
                  nearestLocation: nearestLocations));
            }
          }

          locationCubit.locations[0] = NearestLocationDto(
              locationId: locationCubit.nearestLocationModel.first.id,
              distances: locationCubit.distanceController.first.text);
          //print('first-location ${locationCubit.locations.first}');

          return Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                width: 0.5,
                color: Colors.black,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const FormHeaderTitle(title: "Nearest Location"),
                Utils.verticalSpace(14.0),
                ...List.generate(
                  nearestLocations.length,
                  (index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          if (index != 0) ...[
                            GestureDetector(
                                onTap: () =>
                                    locationCubit.removeLocation(index),
                                child: const DeleteIconBtn()),
                          ],
                          Row(
                            children: [
                              Expanded(
                                child: DropdownButtonFormField<
                                    NearestLocationModel>(
                                  isDense: true,
                                  isExpanded: true,
                                  value:
                                      locationCubit.nearestLocationModel[index],
                                  decoration: const InputDecoration(
                                    filled: true,
                                    fillColor: borderColor,
                                    border: OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: borderColor),
                                    ),
                                  ),
                                  hint: const CustomTextStyle(
                                    text: 'City',
                                    fontWeight: FontWeight.w400,
                                    fontSize: 16.0,
                                  ),
                                  icon: const Icon(
                                      Icons.keyboard_arrow_down_sharp,
                                      color: blackColor),
                                  items: createInfoCubit
                                      .createPropertyInfo!.nearestLocations!
                                      .map<
                                          DropdownMenuItem<
                                              NearestLocationModel>>(
                                        (e) => DropdownMenuItem(
                                          value: e,
                                          child: CustomTextStyle(
                                            text: e.location,
                                            fontSize: 16.0,
                                          ),
                                        ),
                                      )
                                      .toList(),
                                  onChanged: (val) {
                                    if (val != null) {
                                      if (index <
                                          locationCubit.locations.length) {
                                        locationCubit.locations[index] =
                                            NearestLocationDto(
                                                locationId: val.id,
                                                distances: locationCubit
                                                    .locations[index]
                                                    .distances);
                                        propertyBloc
                                            .add(PropertyNearestLocationEvent(
                                          nearestLocation:
                                              locationCubit.locations,
                                        ));
                                      }
                                    }
                                  },
                                ),
                              ),
                              Utils.horizontalSpace(10),
                              Expanded(
                                child: TextFormField(
                                  controller:
                                      locationCubit.distanceController[index],
                                  onChanged: (v) {
                                    print('onChanged-text-field$v');
                                    if (index <
                                        locationCubit.locations.length) {
                                      locationCubit.locations[index] =
                                          NearestLocationDto(
                                              locationId: locationCubit
                                                  .locations[index].locationId,
                                              distances: v);
                                      propertyBloc.add(
                                        PropertyNearestLocationEvent(
                                          nearestLocation:
                                              locationCubit.locations,
                                        ),
                                      );
                                    }
                                  },
                                  decoration: const InputDecoration(
                                      hintText: 'Value *',
                                      labelText: 'Value *',
                                      hintStyle:
                                          TextStyle(color: Colors.black38),
                                      labelStyle: TextStyle(
                                        color: Colors.black38,
                                      )),
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.deny('a'),
                                    FilteringTextInputFormatter.digitsOnly,
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
                GestureDetector(
                    onTap: () {
                      int id = createInfoCubit
                          .createPropertyInfo!.nearestLocations!.first.id;
                      final loc =
                          NearestLocationDto(locationId: id, distances: '');
                      locationCubit.addLocation(loc);
                    },
                    child: const ItemAddBtn()),
              ],
            ),
          );
        }
        return const SizedBox.shrink();
      },
    );
  }
}
