import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../data/model/create_property/property_plan_dto.dart';
import '../../../../logic/bloc/create_property/bloc/property_create_bloc.dart';
import '../../../../logic/bloc/create_property/plan/plan_cubit.dart';
import '../../../utils/constraints.dart';
import '../../../utils/utils.dart';
import '../../../widget/custom_images.dart';
import '../../../widget/custom_test_style.dart';
import '../../../widget/form_header_title.dart';
import '../../../widget/item_add_delete_btn.dart';
import '../../profile/component/person_single_property.dart';

class PlanWidgetView extends StatelessWidget {
  const PlanWidgetView({super.key});

  @override
  Widget build(BuildContext context) {
    final propertyBloc = context.read<PropertyCreateBloc>();
    final planCubit = context.read<PlanCubit>();
    return BlocBuilder<PlanCubit, PlanState>(
      builder: (context, state) {
        final plans = state.propertyPlan;
        propertyBloc.add(PropertyPropertyPlanEvent(propertyPlan: plans));
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              width: 0.5,
              color: Colors.black,
            ),
          ),
          child: Column(
            children: [
              const FormHeaderTitle(title: "Property Plan"),
              Utils.verticalSpace(14.0),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    ...List.generate(plans.length, (index) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          if (index != 0) ...[
                            GestureDetector(
                                onTap: () => planCubit.removeFormItem(index),
                                child: const DeleteIconBtn()),
                          ],
                          _buildImages(planCubit, index),
                          Utils.verticalSpace(16),
                          TextFormField(
                            // controller: index < planCubit.planTitles.length
                            //     ? planCubit.planTitles[index]
                            //     : TextEditingController(),
                            controller: planCubit.planTitles[index],
                            textInputAction: TextInputAction.done,
                            onChanged: (String titles) {
                              planCubit.updateControllers(
                                  index, titles, 'title');
                              propertyBloc.add(PropertyPropertyPlanEvent(
                                  propertyPlan: plans));
                            },
                            decoration: InputDecoration(
                                hintText: index != 0 ? 'title $index' : 'title',
                                labelText:
                                    index != 0 ? 'Title $index' : 'Title',
                                hintStyle:
                                    const TextStyle(color: Colors.black38),
                                labelStyle: const TextStyle(
                                  color: Colors.black38,
                                )),
                            keyboardType: TextInputType.text,
                          ),
                          Utils.verticalSpace(16),
                          TextFormField(
                            // controller: index < planCubit.planDescription.length
                            //     ? planCubit.planDescription[index]
                            //     : TextEditingController(),
                            controller: planCubit.planDescription[index],
                            onChanged: (String titles) {
                              planCubit.updateControllers(
                                  index, titles, 'description');
                              propertyBloc.add(PropertyPropertyPlanEvent(
                                  propertyPlan: plans));
                            },
                            decoration: InputDecoration(
                                hintText: index != 0
                                    ? 'description $index'
                                    : 'description',
                                labelText: index != 0
                                    ? 'Description $index'
                                    : 'Description',
                                hintStyle:
                                    const TextStyle(color: Colors.black38),
                                labelStyle: const TextStyle(
                                  color: Colors.black38,
                                )),
                            keyboardType: TextInputType.text,
                          ),
                        ],
                      );
                    }),
                    GestureDetector(
                        onTap: () {
                          const planItem = PropertyPlanDto(
                            planImages: '',
                            planTitles: '',
                            planDescriptions: '',
                          );
                          planCubit.addFormItem(planItem);
                        },
                        child: const ItemAddBtn()),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildImages(PlanCubit planCubit, int index) {
    if (index < planCubit.planImages.length) {
      if (planCubit.planImages[index].isNotEmpty) {
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
              width: 0.2,
              color: Colors.grey,
            ),
          ),
          child: Stack(
            children: [
              SizedBox(
                height: 160.0,
                width: double.infinity,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10.0),
                  child: CustomImage(
                    path: planCubit.planImages[index],
                    height: 160.0,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    isFile: planCubit.planImages[index].isNotEmpty,
                  ),
                ),
              ),
              Positioned(
                top: 0,
                left: 0,
                child: GestureDetector(
                  onTap: () async {
                    final image = await Utils.pickSingleImage();
                    if (image != null) {
                      planCubit.updateImage(index, image);
                    }
                  },
                  child: const EditBtn(),
                ),
              ),
            ],
          ),
        );
      } else {
        return Container(
          height: 80.0,
          alignment: Alignment.center,
          child: GestureDetector(
            onTap: () async {
              final image = await Utils.pickSingleImage();
              if (image != null) {
                planCubit.updateImage(index, image);
              }
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.upload, size: 24, color: primaryColor),
                Utils.horizontalSpace(8.0),
                const CustomTextStyle(
                  text: "Upload Plan Images",
                  fontSize: 18.0,
                  fontWeight: FontWeight.w600,
                  color: primaryColor,
                )
              ],
            ),
          ),
        );
      }
    }
    return const SizedBox.shrink();
  }
}
