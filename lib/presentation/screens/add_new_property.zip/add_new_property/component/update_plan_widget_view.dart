import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../data/model/create_property/property_plan_dto.dart';
import '../../../../logic/bloc/create_property/bloc/property_create_bloc.dart';
import '../../../../logic/bloc/create_property/plan/plan_cubit.dart';
import '../../../utils/constraints.dart';
import '../../../utils/k_images.dart';
import '../../../utils/utils.dart';
import '../../../widget/custom_images.dart';
import '../../../widget/custom_test_style.dart';
import '../../../widget/form_header_title.dart';
import '../../../widget/item_add_delete_btn.dart';
import '../../profile/component/person_single_property.dart';

class UpdatePlanWidgetView extends StatefulWidget {
  const UpdatePlanWidgetView({super.key});

  @override
  State<UpdatePlanWidgetView> createState() => _UpdatePlanWidgetViewState();
}

class _UpdatePlanWidgetViewState extends State<UpdatePlanWidgetView> {
  List<PropertyPlanDto> properties = [];

  @override
  void initState() {
    //_initExistingPlans();
    super.initState();
  }

  void _initExistingPlans() {
    final propertyBloc = context.read<PropertyCreateBloc>();
    final planCubit = context.read<PlanCubit>();
    properties.clear();
    planCubit.planImages.clear();
    planCubit.planTitles.clear();
    planCubit.planDescription.clear();
    context.read<PlanCubit>().state.propertyPlan.clear();
    if (propertyBloc.propertyPlanList.isNotEmpty) {
      for (int i = 0; i < propertyBloc.propertyPlanList.length; i++) {
        final property = propertyBloc.propertyPlanList[i];
        planCubit.planImages.add(property.planImages);
        planCubit.planTitles.insert(i, TextEditingController());
        planCubit.planTitles[i].text = property.planTitles;
        planCubit.planDescription.insert(i, TextEditingController());
        planCubit.planDescription[i].text = property.planDescriptions;
        properties.add(property);
      }
    }
    debugPrint('plan-images ${planCubit.planImages.length}');
    debugPrint('plan-titles ${planCubit.planTitles.length}');
    debugPrint('plan-description ${planCubit.planDescription.length}');
    //debugPrint('state-images ${planCubit.planImages.length}');
    properties.map((e) => context.read<PlanCubit>().addFormItem(e)).toList();
  }

  @override
  Widget build(BuildContext context) {
    final propertyBloc = context.read<PropertyCreateBloc>();
    final planCubit = context.read<PlanCubit>();
    properties.clear();
    planCubit.planImages.clear();
    planCubit.planTitles.clear();
    planCubit.planDescription.clear();
    context.read<PlanCubit>().state.propertyPlan.clear();
    if (propertyBloc.propertyPlanList.isNotEmpty) {
      for (int i = 0; i < propertyBloc.propertyPlanList.length; i++) {
        final property = propertyBloc.propertyPlanList[i];
        planCubit.planImages.add(property.planImages);
        planCubit.planTitles.insert(i, TextEditingController());
        planCubit.planTitles[i].text = property.planTitles;
        planCubit.planDescription.insert(i, TextEditingController());
        planCubit.planDescription[i].text = property.planDescriptions;
        properties.add(property);
      }
    }
    debugPrint('plan-images ${planCubit.planImages.length}');
    debugPrint('plan-titles ${planCubit.planTitles.length}');
    debugPrint('plan-description ${planCubit.planDescription.length}');
    //debugPrint('state-images ${planCubit.planImages.length}');
    properties.map((e) => context.read<PlanCubit>().addFormItem(e)).toList();
    return BlocBuilder<PlanCubit, PlanState>(
      builder: (context, state) {
        //state.propertyPlan.clear();
        final plans = state.propertyPlan;
        debugPrint('existing-plans ${plans.length}');
        propertyBloc.add(PropertyPropertyPlanEvent(propertyPlan: plans));
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              width: 0.5,
              color: Colors.black,
            ),
          ),
          child: Column(
            children: [
              const FormHeaderTitle(title: "Property Plan"),
              Utils.verticalSpace(14.0),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    ...List.generate(plans.length, (index) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          if (index != 0) ...[
                            GestureDetector(
                                onTap: () => planCubit.removeFormItem(index),
                                child: const DeleteIconBtn()),
                          ],
                          _buildImages(planCubit, index),
                          Utils.verticalSpace(16),
                          TextFormField(
                            controller: planCubit.planTitles[index],
                            textInputAction: TextInputAction.done,
                            onChanged: (String titles) {
                              planCubit.updateControllers(
                                  index, titles, 'title');
                              propertyBloc.add(PropertyPropertyPlanEvent(
                                  propertyPlan: plans));
                            },
                            decoration: InputDecoration(
                                hintText: index != 0 ? 'title $index' : 'title',
                                labelText:
                                    index != 0 ? 'Title $index' : 'Title',
                                hintStyle:
                                    const TextStyle(color: Colors.black38),
                                labelStyle: const TextStyle(
                                  color: Colors.black38,
                                )),
                            keyboardType: TextInputType.text,
                          ),
                          Utils.verticalSpace(16),
                          TextFormField(
                            controller: planCubit.planDescription[index],
                            onChanged: (String titles) {
                              planCubit.updateControllers(
                                  index, titles, 'description');
                              propertyBloc.add(PropertyPropertyPlanEvent(
                                  propertyPlan: plans));
                            },
                            decoration: InputDecoration(
                                hintText: index != 0
                                    ? 'description $index'
                                    : 'description',
                                labelText: index != 0
                                    ? 'Description $index'
                                    : 'Description',
                                hintStyle:
                                    const TextStyle(color: Colors.black38),
                                labelStyle: const TextStyle(
                                  color: Colors.black38,
                                )),
                            keyboardType: TextInputType.text,
                          ),
                        ],
                      );
                    }),
                    GestureDetector(
                        onTap: () {
                          const planItem = PropertyPlanDto(
                            planImages: '',
                            planTitles: '',
                            planDescriptions: '',
                          );
                          planCubit.addFormItem(planItem);
                        },
                        child: const ItemAddBtn()),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildImages(PlanCubit planCubit, int index) {
    debugPrint('total-state-images ${planCubit.planImages.length}');
    if (index < planCubit.planImages.length) {
      if (planCubit.planImages[index].isNotEmpty) {
        final imageItem = planCubit.planImages[index];
        String thumbImage = planCubit.planImages[index].isEmpty
            ? KImages.placeholderImage
            : planCubit.planImages[index];
        bool isFile = planCubit.planImages.isNotEmpty
            ? imageItem.contains('http://') || imageItem.contains('https://')
                ? false
                : true
            : false;
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
              width: 0.2,
              color: Colors.grey,
            ),
          ),
          child: Stack(
            children: [
              SizedBox(
                height: 160.0,
                width: double.infinity,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10.0),
                  child: CustomImage(
                    path: thumbImage,
                    // path: planCubit.planImages[index].startsWith('https') ||
                    //         planCubit.planImages[index].startsWith('http')
                    //     ? RemoteUrls.imageUrl(planCubit.planImages[index])
                    //     : planCubit.planImages[index],
                    height: 160.0,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    //isFile: planCubit.planImages[index].isNotEmpty,
                    isFile: isFile,
                  ),
                ),
              ),
              Positioned(
                top: 0,
                left: 0,
                child: GestureDetector(
                  onTap: () async {
                    final image = await Utils.pickSingleImage();
                    if (image != null) {
                      planCubit.updateImage(index, image);
                    }
                  },
                  child: const EditBtn(),
                ),
              ),
            ],
          ),
        );
      } else {
        return Container(
          height: 80.0,
          alignment: Alignment.center,
          child: GestureDetector(
            onTap: () async {
              final image = await Utils.pickSingleImage();
              if (image != null) {
                planCubit.updateImage(index, image);
              }
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.upload, size: 24, color: primaryColor),
                Utils.horizontalSpace(8.0),
                const CustomTextStyle(
                  text: "Upload Plan Images",
                  fontSize: 18.0,
                  fontWeight: FontWeight.w600,
                  color: primaryColor,
                )
              ],
            ),
          ),
        );
      }
    }
    return const SizedBox.shrink();
  }
}
