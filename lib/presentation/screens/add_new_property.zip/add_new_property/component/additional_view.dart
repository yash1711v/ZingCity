import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../data/model/create_property/additional_info_dto.dart';
import '../../../../logic/bloc/create_property/additional_view/additional_cubit.dart';
import '../../../../logic/bloc/create_property/bloc/property_create_bloc.dart';
import '../../../utils/utils.dart';
import '../../../widget/form_header_title.dart';
import '../../../widget/item_add_delete_btn.dart';

class AdditionalView extends StatelessWidget {
  const AdditionalView({super.key});

  @override
  Widget build(BuildContext context) {
    final additionCubit = context.read<AdditionalCubit>();
    final propertyBloc = context.read<PropertyCreateBloc>();
    return BlocBuilder<AdditionalCubit, AdditionalState>(
      builder: (context, state) {
        if (state is AdditionAdded || state is AdditionRemoved) {
          final additional = (state as AdditionAdded).additionalList;

          for (int i = 0; i < additionCubit.cubitAdditional.length; i++) {
            final keyText = additionCubit.keys[i].text;
            final valueText = additionCubit.keys[i].text;
            if (keyText.isNotEmpty && valueText.isNotEmpty) {
              propertyBloc.add(
                PropertyAdditionalInfoEvent(
                    additionalInfo: additionCubit.cubitAdditional),
              );
            }
          }

          return Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                width: 0.5,
                color: Colors.black,
              ),
            ),
            child: Column(
              children: [
                const FormHeaderTitle(title: "Additional Information"),
                Utils.verticalSpace(14.0),
                ...List.generate(
                  additional.length,
                  (index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0).copyWith(bottom: 0.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          if (index != 0) ...[
                            GestureDetector(
                                onTap: () =>
                                    additionCubit.removeAdditional(index),
                                child: const DeleteIconBtn()),
                          ],
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: TextFormField(
                                  controller: additionCubit.keys[index],
                                  onChanged: (String key) {
                                    if (index <
                                        additionCubit.cubitAdditional.length) {
                                      final values =
                                          additionCubit.values[index].text;
                                      final keyAdditional = AdditionalInfoDto(
                                          addKeys: key, addValues: values);
                                      additionCubit.cubitAdditional[index] =
                                          keyAdditional;

                                      ///instantly updated on state
                                      propertyBloc.add(
                                        PropertyAdditionalInfoEvent(
                                            additionalInfo:
                                                additionCubit.cubitAdditional),
                                      );
                                    }
                                  },
                                  decoration: const InputDecoration(
                                      hintText: 'Key',
                                      labelText: 'Key',
                                      hintStyle:
                                          TextStyle(color: Colors.black38),
                                      labelStyle: TextStyle(
                                        color: Colors.black38,
                                      )),
                                  keyboardType: TextInputType.text,
                                ),
                              ),
                              Utils.horizontalSpace(10),
                              Expanded(
                                child: TextFormField(
                                  controller: additionCubit.values[index],
                                  onChanged: (String value) {
                                    if (index <
                                        additionCubit.cubitAdditional.length) {
                                      final keys =
                                          additionCubit.keys[index].text;
                                      final keyAdditional = AdditionalInfoDto(
                                          addKeys: keys, addValues: value);
                                      additionCubit.cubitAdditional[index] =
                                          keyAdditional;

                                      ///instantly updated on state

                                      propertyBloc.add(
                                        PropertyAdditionalInfoEvent(
                                            additionalInfo:
                                                additionCubit.cubitAdditional),
                                      );
                                    }
                                  },
                                  decoration: const InputDecoration(
                                      hintText: 'Value',
                                      labelText: 'Value',
                                      hintStyle:
                                          TextStyle(color: Colors.black38),
                                      labelStyle: TextStyle(
                                        color: Colors.black38,
                                      )),
                                  keyboardType: TextInputType.text,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
                GestureDetector(
                    onTap: () {
                      const keyValue =
                          AdditionalInfoDto(addKeys: '', addValues: '');
                      additionCubit.addAdditional(keyValue);
                    },
                    child: const ItemAddBtn()),
              ],
            ),
          );
        }
        return const SizedBox.shrink();
      },
    );
  }
}
