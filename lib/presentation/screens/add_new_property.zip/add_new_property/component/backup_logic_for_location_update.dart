// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
//
// import '../../../../data/model/create_property/nearest_location_dto.dart';
// import '../../../../data/model/product/nearest_location_model.dart';
// import '../../../../logic/bloc/create_property/bloc/property_create_bloc.dart';
// import '../../../../logic/bloc/create_property/nearest_location/nearest_location_cubit.dart';
// import '../../../../logic/cubit/create_property/create_info_cubit.dart';
// import '../../../utils/constraints.dart';
// import '../../../utils/utils.dart';
// import '../../../widget/custom_test_style.dart';
// import '../../../widget/form_header_title.dart';
// import '../../../widget/item_add_delete_btn.dart';
//
// class UpdateNearestLocationView extends StatefulWidget {
//   const UpdateNearestLocationView({super.key});
//
//   @override
//   State<UpdateNearestLocationView> createState() =>
//       _UpdateNearestLocationViewState();
// }
//
// class _UpdateNearestLocationViewState extends State<UpdateNearestLocationView> {
//   List<NearestLocationDto> localLocation = [];
//   List<TextEditingController> locationController = [];
//   List<NearestLocationModel> dropdownLocation = [];
//   NearestLocationModel? model;
//   TextEditingController? controller;
//
//   @override
//   Widget build(BuildContext context) {
//     final propertyBloc = context.read<PropertyCreateBloc>();
//     final createInfoCubit = context.read<CreateInfoCubit>();
//     final updateLocationCubit = context.read<NearestLocationCubit>();
//     // final updateLocationCubit = context.read<UpdateNearestLocationCubit>();
//     //print('existing-location ${propertyBloc.editInfo!.existingNearest.length}');
//     if (propertyBloc.editInfo != null &&
//         propertyBloc.editInfo!.existingNearest.isNotEmpty) {
//       localLocation.clear();
//       dropdownLocation.clear();
//       // locationController.clear();
//       for (int i = 0; i < propertyBloc.editInfo!.existingNearest.length; i++) {
//         final existingLocations = propertyBloc.editInfo!.existingNearest[i];
//         final newLocations = NearestLocationDto(
//           locationId: existingLocations.nearestLocationId,
//           distances: existingLocations.distance,
//         );
//         final locationModel = NearestLocationModel(
//           id: existingLocations.nearestLocationId,
//           location: existingLocations.distance,
//           status: 1,
//         );
//         // final controller = TextEditingController(text: newLocations.distances);
//         // print('controllerText ${controller.text}');
//         //context.read<NearestLocationCubit>().addLocation(newLocations);
//         // print(
//         //     'loc | locId | id  -> ${existingLocations.distance} | ${existingLocations.nearestLocationId} | ${existingLocations.id}');
//         // debugPrint('newLocations $newLocations');
//         // debugPrint('locationModel $locationModel');
//         localLocation.add(newLocations);
//         dropdownLocation.add(locationModel);
//         // locationController.add(controller);
//       }
//     }
//     updateLocationCubit.locations.clear();
//     updateLocationCubit.nearestLocationModel.clear();
//     localLocation
//         .map((e) => context.read<NearestLocationCubit>().addLocation(e))
//         .toList();
//     dropdownLocation
//         .map((e) =>
//             context.read<NearestLocationCubit>().nearestLocationModel.add(e))
//         .toList();
//     // locationController.map(
//     //     (e) => context.read<NearestLocationCubit>().distanceController.add(e));
//     // propertyBloc.add(PropertyNearestLocationEvent(
//     //     nearestLocation: updateLocationCubit.locations));
//
//     // for (int i = 0; i < propertyBloc.state.nearestLocationList.length; i++) {
//     //   final nl = propertyBloc.state.nearestLocationList[i];
//     //   print('n-loca ${nl.distances}');
//     // }
//
//     // print('localLocation ${dropdownLocation.length}');
//     // print('dropdownLocation ${localLocation.length}');
//     // print('state-model ${updateLocationCubit.nearestLocationModel}');
//     for (int i = 0; i < locationController.length; i++) {
//       print('locationControllerText ${locationController[i].text}');
//     }
//     for (int i = 0; i < updateLocationCubit.locations.length; i++) {
//       updateLocationCubit.nearestLocationModel[i] = createInfoCubit
//           .createPropertyInfo!.nearestLocations
//           .where((element) => element.id == localLocation[i].locationId)
//           .first;
//     }
//     model = createInfoCubit.createPropertyInfo!.nearestLocations.first;
//
//     for (int i = 0; i < propertyBloc.nearestLocationList.length; i++) {
//       final data = propertyBloc.nearestLocationList[i];
//       print('id|dis|jid ${data.locationId}|${data.distances}|${data.id}');
//     }
//
//     return BlocBuilder<NearestLocationCubit, NearestLocationState>(
//       builder: (context, state) {
//         if (state is NearestLocationAdded || state is NearestLocationRemoved) {
//           final nearestLocations =
//               (state as NearestLocationAdded).nearestLocation;
//
//           //nearestLocations.addAll(localLocation);
//           // print('state-location ${state.nearestLocation.length}');
//           // print('state-location ${state.nearestLocation}');
//           // if (propertyBloc.editInfo != null) {
//           //   final create = propertyBloc.editInfo;
//           //   if (create!.existingNearest.isNotEmpty) {
//           //     final exitList = create.existingNearest;
//           //     //print('exitList ${exitList}');
//           //
//           //     for (int i = 0; i < exitList.length; i++) {
//           //       final loc = exitList[i];
//           //       updateLocationCubit.exitLocationIds.add(loc.nearestLocationId);
//           //       updateLocationCubit.exitDistances.add(loc.distance);
//           //       final model = NearestLocationModel(
//           //           id: loc.nearestLocationId,
//           //           location: loc.distance,
//           //           status: 1);
//           //       updateLocationCubit.exitModel.add(model);
//           //     }
//           //     // final list = exitList
//           //     //     .map((e) => updateLocationCubit.locations.add(
//           //     //         NearestLocationDto(
//           //     //             locationId: e.nearestLocationId,
//           //     //             distances: e.distance)))
//           //     //     .toList();
//           //     // print('ext-list ${list.length}');
//           //     //context.read<NearestLocationCubit>().addLocation();
//           //   }
//           // }
//           //print('ids ${updateLocationCubit.exitLocationIds}');
//           //print('distance ${updateLocationCubit.exitDistances}');
//           //print('model ${updateLocationCubit.exitModel}');
//
//           return Container(
//             decoration: BoxDecoration(
//               borderRadius: BorderRadius.circular(10),
//               border: Border.all(
//                 width: 0.5,
//                 color: Colors.black,
//               ),
//             ),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 const FormHeaderTitle(title: "Nearest Location"),
//                 Utils.verticalSpace(14.0),
//                 ...List.generate(
//                   nearestLocations.length,
//                   // nearestLocations.length,
//                   // updateLocationCubit.nearestLocationModel.length,
//                   (index) {
//                     return Padding(
//                       padding: const EdgeInsets.all(8.0),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.end,
//                         children: [
//                           if (index != 0) ...[
//                             GestureDetector(
//                                 onTap: () =>
//                                     updateLocationCubit.removeLocation(index),
//                                 child: const DeleteIconBtn()),
//                           ],
//                           Row(
//                             children: [
//                               Expanded(
//                                 child: DropdownButtonFormField<
//                                     NearestLocationModel>(
//                                   isDense: true,
//                                   isExpanded: true,
//                                   value: index < localLocation.length
//                                       ? updateLocationCubit
//                                           .nearestLocationModel[index]
//                                       : model,
//                                   decoration: const InputDecoration(
//                                     filled: true,
//                                     fillColor: borderColor,
//                                     border: OutlineInputBorder(
//                                       borderSide:
//                                           BorderSide(color: borderColor),
//                                     ),
//                                   ),
//                                   hint: const CustomTextStyle(
//                                     text: 'City',
//                                     fontWeight: FontWeight.w400,
//                                     fontSize: 16.0,
//                                   ),
//                                   icon: const Icon(
//                                       Icons.keyboard_arrow_down_sharp,
//                                       color: blackColor),
//                                   items: createInfoCubit
//                                       .createPropertyInfo!.nearestLocations
//                                       .map<
//                                           DropdownMenuItem<
//                                               NearestLocationModel>>(
//                                         (e) => DropdownMenuItem(
//                                           value: e,
//                                           child: CustomTextStyle(
//                                             text: e.location,
//                                             fontSize: 16.0,
//                                           ),
//                                         ),
//                                       )
//                                       .toList(),
//                                   onChanged: (val) {
//                                     if (val != null) {
//                                       if (index <
//                                           updateLocationCubit
//                                               .locations.length) {
//                                         updateLocationCubit.locations[index] =
//                                             NearestLocationDto(
//                                                 locationId: val.id,
//                                                 distances: updateLocationCubit
//                                                     .locations[index]
//                                                     .distances);
//                                         propertyBloc
//                                             .add(PropertyNearestLocationEvent(
//                                           nearestLocation:
//                                               updateLocationCubit.locations,
//                                         ));
//                                       }
//                                     }
//
//                                     // if (val != null) {
//                                     //   final nearestDto = NearestLocationDto(
//                                     //       locationId: val.id, distances: '');
//                                     //   updateLocationCubit.updateLocation(
//                                     //       index, nearestDto);
//                                     // }
//                                   },
//                                 ),
//                               ),
//                               Utils.horizontalSpace(10),
//                               Expanded(
//                                 child: TextFormField(
//                                   controller: index < nearestLocations.length
//                                       ? updateLocationCubit
//                                           .distanceController[index]
//                                       : TextEditingController(),
//                                   // initialValue:
//                                   //     state.nearestLocation[index].distances,
//                                   onChanged: (v) {
//                                     print('onChanged-text-field$v');
//                                     if (index < localLocation.length) {
//                                       localLocation[index] = NearestLocationDto(
//                                           locationId:
//                                               localLocation[index].locationId,
//                                           distances: v);
//                                       propertyBloc.add(
//                                         PropertyNearestLocationEvent(
//                                           nearestLocation: localLocation,
//                                         ),
//                                       );
//                                     }
//                                   },
//                                   decoration: const InputDecoration(
//                                       hintText: 'Value *',
//                                       labelText: 'Value *',
//                                       hintStyle:
//                                           TextStyle(color: Colors.black38),
//                                       labelStyle: TextStyle(
//                                         color: Colors.black38,
//                                       )),
//                                   keyboardType: TextInputType.number,
//                                   inputFormatters: [
//                                     FilteringTextInputFormatter.deny('a'),
//                                     FilteringTextInputFormatter.digitsOnly,
//                                   ],
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ],
//                       ),
//                     );
//                   },
//                 ),
//                 GestureDetector(
//                     onTap: () {
//                       int id = createInfoCubit
//                           .createPropertyInfo!.nearestLocations.first.id;
//                       final loc =
//                           NearestLocationDto(locationId: id, distances: '');
//                       updateLocationCubit.addLocation(loc);
//                     },
//                     child: const ItemAddBtn()),
//               ],
//             ),
//           );
//         }
//         return const SizedBox.shrink();
//       },
//     );
//   }
//
//   BlocBuilder<UpdateNearestLocationCubit, UpdateNearestLocationState>
//       previousCode(
//           PropertyCreateBloc propertyBloc,
//           UpdateNearestLocationCubit updateLocationCubit,
//           CreateInfoCubit createInfoCubit) {
//     return BlocBuilder<UpdateNearestLocationCubit, UpdateNearestLocationState>(
//       builder: (context, state) {
//         print('total-state-length ${state.locations.length}');
//         // updateLocationCubit.nearestLocationModel.insert(
//         //     0, createInfoCubit.createPropertyInfo!.nearestLocations.first);
//
//         if (propertyBloc.editInfo!.existingNearest.isNotEmpty) {
//           final list = propertyBloc.editInfo!.existingNearest;
//           final extLocations = list
//               .map((e) => NearestLocationDto(
//                   locationId: e.nearestLocationId, distances: e.distance))
//               .toList();
//
//           // final updatedLocations =
//           //     List<NearestLocationDto>.from(state.locations);
//           // updatedLocations.addAll(extLocations);
//           // updateLocationCubit
//           //     .initExistingLocation([...state.locations, ...extLocations]);
//           context
//               .read<UpdateNearestLocationCubit>()
//               .initExistingLocation([...state.locations, ...extLocations]);
//         }
//
//         print('state-length ${state.locations.length}');
//
//         return Container(
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(10),
//             border: Border.all(
//               width: 0.5,
//               color: Colors.black,
//             ),
//           ),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               const FormHeaderTitle(title: "Nearest Location"),
//               Utils.verticalSpace(14.0),
//               ...List.generate(
//                 state.locations.length,
//                 // updateLocationCubit.nearestLocationModel.length,
//                 (index) {
//                   return Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.end,
//                       children: [
//                         if (index != 0) ...[
//                           GestureDetector(
//                               onTap: () =>
//                                   updateLocationCubit.removeLocation(index),
//                               child: const DeleteIconBtn()),
//                         ],
//                         Row(
//                           children: [
//                             Expanded(
//                               child:
//                                   DropdownButtonFormField<NearestLocationModel>(
//                                 isDense: true,
//                                 isExpanded: true,
//                                 value: updateLocationCubit
//                                     .nearestLocationModel[index],
//                                 decoration: const InputDecoration(
//                                   filled: true,
//                                   fillColor: borderColor,
//                                   border: OutlineInputBorder(
//                                     borderSide: BorderSide(color: borderColor),
//                                   ),
//                                 ),
//                                 hint: const CustomTextStyle(
//                                   text: 'City',
//                                   fontWeight: FontWeight.w400,
//                                   fontSize: 16.0,
//                                 ),
//                                 icon: const Icon(
//                                     Icons.keyboard_arrow_down_sharp,
//                                     color: blackColor),
//                                 items: createInfoCubit
//                                     .createPropertyInfo!.nearestLocations
//                                     .map<
//                                         DropdownMenuItem<NearestLocationModel>>(
//                                       (e) => DropdownMenuItem(
//                                         value: e,
//                                         child: CustomTextStyle(
//                                           text: e.location,
//                                           fontSize: 16.0,
//                                         ),
//                                       ),
//                                     )
//                                     .toList(),
//                                 onChanged: (val) {
//                                   // if (val != null) {
//                                   //   if (index <
//                                   //       updateLocationCubit.locations.length) {
//                                   //     updateLocationCubit.locations[index] =
//                                   //         NearestLocationDto(
//                                   //             locationId: val.id,
//                                   //             distances: updateLocationCubit
//                                   //                 .locations[index]
//                                   //                 .distances);
//                                   //     propertyBloc
//                                   //         .add(PropertyNearestLocationEvent(
//                                   //       nearestLocation:
//                                   //       locationCubit.locations,
//                                   //     ));
//                                   //   }
//                                   // }
//
//                                   if (val != null) {
//                                     final nearestDto = NearestLocationDto(
//                                         locationId: val.id, distances: '');
//                                     updateLocationCubit.updateLocation(
//                                         index, nearestDto);
//                                   }
//                                 },
//                               ),
//                             ),
//                             Utils.horizontalSpace(10),
//                             Expanded(
//                               child: TextFormField(
//                                 // controller:
//                                 //     locationCubit.distanceController[index],
//                                 onChanged: (v) {
//                                   print('onChanged-text-field$v');
//                                   // if (index <
//                                   //     locationCubit.locations.length) {
//                                   //   locationCubit.locations[index] =
//                                   //       NearestLocationDto(
//                                   //           locationId: locationCubit
//                                   //               .locations[index]
//                                   //               .locationId,
//                                   //           distances: v);
//                                   //   propertyBloc.add(
//                                   //     PropertyNearestLocationEvent(
//                                   //       nearestLocation:
//                                   //       locationCubit.locations,
//                                   //     ),
//                                   //   );
//                                   // }
//                                 },
//
//                                 decoration: const InputDecoration(
//                                     hintText: 'Value *',
//                                     labelText: 'Value *',
//                                     hintStyle: TextStyle(color: Colors.black38),
//                                     labelStyle: TextStyle(
//                                       color: Colors.black38,
//                                     )),
//                                 keyboardType: TextInputType.number,
//                                 inputFormatters: [
//                                   FilteringTextInputFormatter.deny('a'),
//                                   FilteringTextInputFormatter.digitsOnly,
//                                 ],
//                               ),
//                             ),
//                           ],
//                         ),
//                       ],
//                     ),
//                   );
//                 },
//               ),
//               GestureDetector(
//                   onTap: () {
//                     int id = createInfoCubit
//                         .createPropertyInfo!.nearestLocations.first.id;
//                     final loc =
//                         NearestLocationDto(locationId: id, distances: '');
//                     updateLocationCubit.addLocation(loc);
//                   },
//                   child: const ItemAddBtn()),
//             ],
//           ),
//         );
//       },
//     );
//   }
// }
//
// // so now i want to assign all nearest_location_id and distance
// // in the locations from Cubit class
// // like NearestLocationDto(locationId: nearest_location_id, distances: distance);
// // and its lenght should be the total length is qual to existing_nearest_locations list length;
// //
// // and also when i triggered addLocation an empty NearestLocationDto is created and when triggerded
// // removeLocation function then item will be removed indexly;
// //
// // and also all update from DropdownButtonFormField and TextFormField will also be updated..AnimatedContainer
// //
// // Note: the functions and logic of Cubit class is used for another class for createing new product
// // and this is for update product; if needed, make some others states or functions inside cubit class..
// // void initExitLocation() {
// //   final propertyBloc = context.read<PropertyCreateBloc>();
// //   final locationCubit = context.read<NearestLocationCubit>();
// //   if (propertyBloc.editInfo!.existingNearest.isNotEmpty) {
// //     final location = propertyBloc.editInfo!.existingNearest;
// //     for (int i = 0; i < location.length; i++) {
// //       final item = location[i];
// //       // print('single-item-dis ${item.distance}');
// //       // print('single-item $item');
// //       final model = NearestLocationDto(
// //           locationId: item.nearestLocationId, distances: item.distance);
// //       locationCubit.locations.add(model);
// //     }
// //   }
// // }
//
// //if (propertyBloc.nearestLocationList.isNotEmpty) {
// //locationCubit.locations = propertyBloc.nearestLocationList;
//
// //nearestLocations.length = locationCubit.locations.length;
// //list = nearestLocations.length;
// // nearestLocations.length = propertyBloc.nearestLocationList.length;
// //}
//
// // for (int i = 0; i < locationCubit.locations.length; i++) {
// //   locationCubit.distanceController.insert(i, TextEditingController());
// //   if (locationCubit.locations[i].locationId > 0) {
// //     final item = createInfoCubit.createPropertyInfo!.nearestLocations
// //         .where((e) => e.id == locationCubit.locations[i].locationId)
// //         .first;
// //     locationCubit.nearestLocationModel.insert(i, item);
// //   } else {
// //     locationCubit.nearestLocationModel.insert(i,
// //         createInfoCubit.createPropertyInfo!.nearestLocations.first);
// //   }
// //   locationCubit.locations.add(
// //     NearestLocationDto(
// //         locationId: locationCubit.locations[i].locationId,
// //         distances: locationCubit.distanceController[i].text),
// //   );
// // }
//
// // final nearestLocations =
// //     (state as NearestLocationAdded).nearestLocation.length;
// // if (propertyBloc.editInfo!.existingNearest.isNotEmpty) {
// //   totalLocationLength = propertyBloc.editInfo!.existingNearest;
// // }
// // {
// //   print('exception-from-else BLOC');
// // }
// // final nearestLocations =
// //     (state as NearestLocationAdded).nearestLocation;
// //
// // //print('nearestLocations-length $nearestLocations');
// // print('nearestLocations-length $totalLocationLength');
// // if (propertyBloc.editInfo!.existingNearest.isNotEmpty) {
// //   final exitingItem = propertyBloc.editInfo!.existingNearest;
// //   for (int i = 0; i < exitingItem.length; i++) {
// //     locationCubit.locations.add(NearestLocationDto(
// //       locationId: totalLocationLength[i].nearestLocationId,
// //       distances: totalLocationLength[i].distance,
// //     ));
// //   }
// // } else {
// //   locationCubit.locations[0] = NearestLocationDto(
// //       locationId: locationCubit.nearestLocationModel.first.id,
// //       distances: locationCubit.distanceController.first.text);
// // }
// // print('locationCubit.locations ${locationCubit.locations}');
//
// ///last updated code
// // print('total-state-length ${state.locations.length}');
// // // updateLocationCubit.nearestLocationModel.insert(
// // //     0, createInfoCubit.createPropertyInfo!.nearestLocations.first);
// //
// // if (propertyBloc.editInfo!.existingNearest.isNotEmpty) {
// //   final list = propertyBloc.editInfo!.existingNearest;
// //   final extLocations = list
// //       .map((e) => NearestLocationDto(
// //           locationId: e.nearestLocationId, distances: e.distance))
// //       .toList();
// //
// //   // final updatedLocations =
// //   //     List<NearestLocationDto>.from(state.locations);
// //   // updatedLocations.addAll(extLocations);
// //   // updateLocationCubit
// //   //     .initExistingLocation([...state.locations, ...extLocations]);
// //   context
// //       .read<UpdateNearestLocationCubit>()
// //       .initExistingLocation([...state.locations, ...extLocations]);
// // }
// //
// // print('state-length ${state.locations.length}');
