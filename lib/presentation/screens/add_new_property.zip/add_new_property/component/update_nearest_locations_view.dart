import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../data/model/create_property/nearest_location_dto.dart';
import '../../../../data/model/product/nearest_location_model.dart';
import '../../../../logic/bloc/create_property/bloc/property_create_bloc.dart';
import '../../../../logic/bloc/create_property/nearest_location/nearest_location_cubit.dart';
import '../../../../logic/cubit/create_property/create_info_cubit.dart';
import '../../../utils/constraints.dart';
import '../../../utils/utils.dart';
import '../../../widget/custom_test_style.dart';
import '../../../widget/form_header_title.dart';
import '../../../widget/item_add_delete_btn.dart';

class UpdateNearestLocationView extends StatefulWidget {
  const UpdateNearestLocationView({super.key});

  @override
  State<UpdateNearestLocationView> createState() =>
      _UpdateNearestLocationViewState();
}

class _UpdateNearestLocationViewState extends State<UpdateNearestLocationView> {
  List<NearestLocationDto> localLocation = [];
  List<NearestLocationModel> locationModel = [];
  NearestLocationModel? model;

  @override
  void initState() {
    _initExistingData();
    super.initState();
  }

  _initExistingData() {
    final propertyBloc = context.read<PropertyCreateBloc>();
    final createInfoCubit = context.read<CreateInfoCubit>();
    final locationCubit = context.read<NearestLocationCubit>();
    localLocation.clear();
    locationModel.clear();
    //locationController.clear();
    locationCubit.locations.clear();
    locationCubit.nearestLocationModel.clear();
    locationCubit.distanceController.clear();
    for (int i = 0; i < propertyBloc.nearestLocationList.length; i++) {
      final existingId = propertyBloc.nearestLocationList[i];
      final existModel = NearestLocationModel(
          id: existingId.locationId, location: existingId.distances, status: 1);
      localLocation.add(propertyBloc.nearestLocationList[i]);
      locationModel.add(existModel);
      locationCubit.distanceController.insert(i, TextEditingController());
      locationCubit.distanceController[i].text =
          propertyBloc.nearestLocationList[i].distances;
    }
    localLocation
        .map((e) => context.read<NearestLocationCubit>().addLocation(e))
        .toList();
    locationModel
        .map((e) =>
            context.read<NearestLocationCubit>().nearestLocationModel.add(e))
        .toList();

    for (int i = 0; i < locationModel.length; i++) {
      locationCubit.nearestLocationModel[i] = createInfoCubit
          .createPropertyInfo!.nearestLocations!
          .where((element) => element.id == localLocation[i].locationId)
          .first;
    }
    model = createInfoCubit.createPropertyInfo!.nearestLocations!.first;
  }

  @override
  Widget build(BuildContext context) {
    final propertyBloc = context.read<PropertyCreateBloc>();
    final createInfoCubit = context.read<CreateInfoCubit>();
    final locationCubit = context.read<NearestLocationCubit>();
    // debugPrint('localLocation-length ${localLocation.length}');
    // debugPrint('dropdownLocation-length ${locationModel.length}');
    // debugPrint('controller-value ${locationCubit.distanceController.length}');
    // debugPrint('state-location-length ${locationCubit.locations.length}');
    // debugPrint('state-location ${locationCubit.locations}');
    // debugPrint('state-nearest-location ${locationCubit.nearestLocationModel}');
    return BlocBuilder<NearestLocationCubit, NearestLocationState>(
      builder: (context, state) {
        if (state is NearestLocationAdded || state is NearestLocationRemoved) {
          final nearestLocations =
              (state as NearestLocationAdded).nearestLocation;
          propertyBloc.add(
            PropertyNearestLocationEvent(
              nearestLocation: nearestLocations,
            ),
          );
          return Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                width: 0.5,
                color: Colors.black,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const FormHeaderTitle(title: "Nearest Location"),
                Utils.verticalSpace(14.0),
                ...List.generate(
                  nearestLocations.length,
                  // nearestLocations.length,
                  // locationCubit.nearestLocationModel.length,
                  (index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          if (index != 0) ...[
                            GestureDetector(
                                onTap: () =>
                                    locationCubit.removeLocation(index),
                                child: const DeleteIconBtn()),
                          ],
                          Row(
                            children: [
                              Expanded(
                                child: _locationCityField(index, locationCubit,
                                    createInfoCubit, propertyBloc, state),
                              ),
                              Utils.horizontalSpace(10),
                              Expanded(
                                child: _locationField(
                                    index, locationCubit, propertyBloc, state),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
                GestureDetector(
                    onTap: () {
                      int id = createInfoCubit
                          .createPropertyInfo!.nearestLocations!.first.id;
                      final loc =
                          NearestLocationDto(locationId: id, distances: '');
                      locationCubit.addLocation(loc);
                    },
                    child: const ItemAddBtn()),
              ],
            ),
          );
        }
        return const SizedBox.shrink();
      },
    );
  }

  Widget _locationField(
    int index,
    NearestLocationCubit locationCubit,
    PropertyCreateBloc propertyBloc,
    NearestLocationAdded state,
  ) {
    return TextFormField(
      controller: index < locationCubit.distanceController.length
          ? locationCubit.distanceController[index]
          : TextEditingController(),
      onChanged: (v) {
        print('onChanged-text-field$v');
        if (index < locationCubit.distanceController.length) {
          locationCubit.locations[index] = NearestLocationDto(
              locationId: locationCubit.locations[index].locationId,
              distances: v);
          propertyBloc.add(
            PropertyNearestLocationEvent(
              nearestLocation: state.nearestLocation,
            ),
          );
        }
      },
      decoration: const InputDecoration(
          hintText: 'Value *',
          labelText: 'Value *',
          hintStyle: TextStyle(color: Colors.black38),
          labelStyle: TextStyle(
            color: Colors.black38,
          )),
      keyboardType: TextInputType.number,
      inputFormatters: [
        FilteringTextInputFormatter.deny('a'),
        FilteringTextInputFormatter.digitsOnly,
      ],
    );
  }

  Widget _locationCityField(
    int index,
    NearestLocationCubit locationCubit,
    CreateInfoCubit createInfoCubit,
    PropertyCreateBloc propertyBloc,
    NearestLocationAdded state,
  ) {
    return DropdownButtonFormField<NearestLocationModel>(
      isDense: true,
      isExpanded: true,
      value: index < localLocation.length
          ? locationCubit.nearestLocationModel[index]
          : model,
      decoration: const InputDecoration(
        filled: true,
        fillColor: borderColor,
        border: OutlineInputBorder(
          borderSide: BorderSide(color: borderColor),
        ),
      ),
      hint: const CustomTextStyle(
        text: 'City',
        fontWeight: FontWeight.w400,
        fontSize: 16.0,
      ),
      icon: const Icon(Icons.keyboard_arrow_down_sharp, color: blackColor),
      items: createInfoCubit.createPropertyInfo!.nearestLocations!
          .map<DropdownMenuItem<NearestLocationModel>>(
            (e) => DropdownMenuItem(
              value: e,
              child: CustomTextStyle(
                text: e.location,
                fontSize: 16.0,
              ),
            ),
          )
          .toList(),
      onChanged: (val) {
        if (val != null) {
          print('drop-id ${val.id}');
          print('drop-location ${val.location}');
          if (index < locationCubit.locations.length) {
            locationCubit.locations[index] = NearestLocationDto(
                locationId: val.id,
                distances: locationCubit.locations[index].distances);
            propertyBloc.add(PropertyNearestLocationEvent(
                nearestLocation: state.nearestLocation));
          }
        }
      },
    );
  }
}
