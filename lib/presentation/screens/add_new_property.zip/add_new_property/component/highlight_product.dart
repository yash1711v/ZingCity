import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../logic/bloc/create_property/bloc/property_create_bloc.dart';
import '../../../utils/constraints.dart';
import '../../../widget/custom_test_style.dart';

class HighLightProperty extends StatelessWidget {
  const HighLightProperty({super.key});

  @override
  Widget build(BuildContext context) {
    final propertyBloc = context.read<PropertyCreateBloc>();
    return BlocBuilder<PropertyCreateBloc, PropertyCreateModel>(
        builder: (context, state) {
      String isTop = state.isTop;
      String isUrgent = state.isUrgent;
      String isFeatured = state.isFeatured;
      String enable = 'enable';
      String disable = '';
      return Column(
        children: [
          Row(
            children: [
              Checkbox(
                  activeColor: primaryColor,
                  value: isTop == enable ? true : false,
                  onChanged: (bool? val) {
                    if (val != null) {
                      isTop = isTop == disable ? enable : disable;
                      propertyBloc.add(PropertyCreateEventTop(isTop));
                      print('isTop : $isTop');
                    }
                  }),
              const CustomTextStyle(
                  text: 'Top Property', fontSize: 16.0, color: primaryColor)
            ],
          ),
          Row(
            children: [
              Checkbox(
                  activeColor: primaryColor,
                  value: isFeatured == enable ? true : false,
                  onChanged: (bool? val) {
                    if (val != null) {
                      isFeatured = isFeatured == disable ? enable : disable;
                      propertyBloc.add(PropertyCreateEventFeature(isFeatured));
                      print('isFeatured : $isFeatured');
                    }
                  }),
              const CustomTextStyle(
                  text: 'Feature Property', fontSize: 16.0, color: primaryColor)
            ],
          ),
          Row(
            children: [
              Checkbox(
                  activeColor: primaryColor,
                  value: isUrgent == enable ? true : false,
                  onChanged: (bool? val) {
                    if (val != null) {
                      isUrgent = isUrgent == disable ? enable : disable;
                      propertyBloc.add(PropertyCreateEventUrgent(isUrgent));
                      print('isUrgent : $isUrgent');
                    }
                  }),
              const CustomTextStyle(
                  text: 'Urgent Property', fontSize: 16.0, color: primaryColor)
            ],
          ),
        ],
      );
    });
  }
}
